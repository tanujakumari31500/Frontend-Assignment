import React from "react";
import ReactDOM from "react-dom";
import { createStore } from "redux";
import MovieBox from "./components/MovieBox";
import counter from "./reducers";

const store = createStore(
  counter,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);
const rootEl = document.getElementById("root");

const render = () => {
  ReactDOM.render(
    <MovieBox
      favourites={store.getState()}
      updateFav={(arr) => store.dispatch({ type: "UPDATE", response: arr })}
    />,
    rootEl
  );
};
render();
store.subscribe(render);
