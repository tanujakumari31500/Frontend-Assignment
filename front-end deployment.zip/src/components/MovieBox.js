import React, { Component, PropTypes } from "react";
import "./movieBox.css";

class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      movieData: [],
      error: "",
      movieName: "",
      favoritesSelected: false
    };
  }

  incrementIfOdd = () => {
    if (this.props.value % 2 !== 0) {
      this.props.onIncrement();
    }
  };

  incrementAsync = () => {
    setTimeout(this.props.onIncrement, 1000);
  };

  debounce(func, timeout = 2000) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func.apply(this, args);
      }, timeout);
    };
  }

  searchMovie(mvValue) {
    console.log(mvValue);
    fetch(`https://www.omdbapi.com/?apikey=1742df3a&s=${mvValue}`)
      .then((results) => {
        return results.json();
      })
      .then((data) => {
        console.log("data >>", data);
        if (data.Search) {
          this.setState({
            movieData: data.Search,
            error: "",
            movieName: mvValue
          });
        }
        if (data.Error) {
          this.setState({
            movieData: [],
            error: data.Error,
            movieName: mvValue
          });
        }
      });
  }

  favoriteFn(mv) {
    const fv = [...this.props.favourites];
    const objIndex = fv.findIndex((obj) => obj.imdbID === mv.imdbID);
    if (objIndex === -1) {
      fv.push(mv);
    } else {
      fv.splice(objIndex, 1);
    }
    this.props.updateFav(fv);
  }

  render() {
    const { error, movieData, movieName, favoritesSelected } = this.state;
    console.log(this.props.favourites, favoritesSelected);
    const { favourites } = this.props;
    return (
      <div>
        <input
          placeholder="Search Movie"
          onChange={(e) => this.debounce(this.searchMovie(e.target.value))}
        />
        <button
          style={{
            marginLeft: "10px",
            background: favoritesSelected ? "green" : ""
          }}
          onClick={() =>
            this.setState({ favoritesSelected: !favoritesSelected })
          }
        >
          Favorites
        </button>
        {!favoritesSelected && movieName && movieData.length > 0 && (
          <div>
            <div> Movies starting with {movieName}</div>
            {movieData.map((mv) => (
              <div style={{ padding: "5px" }}>
                <div>
                  {mv.Title} - {mv.Year}
                  <button className="fvrt" onClick={() => this.favoriteFn(mv)}>
                    {favourites.findIndex((obj) => obj.imdbID === mv.imdbID) ===
                    -1
                      ? "Add to"
                      : "Remove from"}{" "}
                    Favorites
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        {!favoritesSelected && movieName && error && <div>{error}</div>}
        {favoritesSelected && favourites.length > 0 && (
          <div>
            {favourites.map((mv) => (
              <div style={{ padding: "5px" }}>
                <div>
                  {mv.Title} - {mv.Year}
                  <button className="fvrt" onClick={() => this.favoriteFn(mv)}>
                    Remove from Favorites
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }
}

Counter.propTypes = {
  favourites: PropTypes.arr,
  updateFav: PropTypes.func
};

export default Counter;
